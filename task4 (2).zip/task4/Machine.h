#ifndef MACHINE_H
#define MACHINE_H

#include "CPU.h"
#include "Memory.h"

class Machine {
    private:
    CPU processor;

    public:
    void loadProgramFile(std::ifstream& file);
    void outputState();

};




#endif
