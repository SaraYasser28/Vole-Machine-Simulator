#include "CU.h"

#include <iostream>
#include <bitset>
#include <cstdint>

void CU::load(int R, int XY, Register& reg, Memory& mem) {
    std::cout << "Loading from memory to register..." << std::endl;
    int val = std::stoi(mem.getCell(XY),nullptr,16);
    reg.setCell(R, val);
}

void CU::load(int R, int val, Register& reg) {
    std::cout << "Loading value into register..." << std::endl;
    reg.setCell(R, val);
}

void CU::store(int R, int XY, Register& reg, Memory& mem) {
    std::cout << "Storing from register to memory..." << std::endl;
    mem.setCell(XY, std::to_string(reg.getCell(R)));
}

void CU::move(int R, int S, Register& reg) {
    std::cout << "Moving data between registers..." << std::endl;
    int t = reg.getCell(R);
    int val = reg.getCell(S);
    reg.setCell(R, val);
    reg.setCell(S, t);
}

void CU::jump(int R, int XY, Register& reg, int& PC , char& op) {
    bool cond1 = op == 'B' && reg.getCell(R) == reg.getCell(0);
    bool cond2 = op == 'D' && reg.getCell(R) > reg.getCell(0);
    if(cond1 || cond2){
        std::cout << "Jumping to memory location..." << std::endl;
        if(XY % 2 == 0){
            PC = XY;
        }else{
            PC = XY - 1;
        }
    }
}

int rotl(int value, int shift, int bit_width = 8) {
    // Mask the value to 8 bits
    value &= 0xFF;

    // Perform the rotation
    shift %= bit_width;
    return ((value >> shift) | (value << (bit_width - shift))) & 0xFF;
}
void CU::rotate(int R, int X, Register& reg){
    int val = rotl(reg.getCell(R),X);
    reg.setCell(R, val);
}

