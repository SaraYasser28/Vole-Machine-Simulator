#ifndef ALU_H
#define ALU_H

#include "Register.h"
#include <iostream>
#define RED "\033[31m"
#define RESET "\033[0m"

class ALU {
    public:
    std::string decToHex(int& dec);
    int hexToDec(const std::string& hex);
    bool isValid(const std::string& value);
    void add(int R, int S, int T, Register&reg);
    void OR(int R, int S, int T, Register&reg);
    void AND(int R, int S, int T, Register&reg);
    void XOR(int R, int S, int T, Register&reg);
    
};


#endif