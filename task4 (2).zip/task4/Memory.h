#ifndef MEMO_H
#define MEMO_H

#include <string>
#include <vector>
#include <iostream>
#define RED "\033[31m"
#define RESET "\033[0m"

class Memory {
    private:
    int size = 256;
    std::vector<std::string> memory;

    public:
    Memory();
    std::string getCell(int address) const;
    void setCell(int address, const std::string& val);
};




#endif