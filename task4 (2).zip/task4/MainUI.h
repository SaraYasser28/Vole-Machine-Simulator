#ifndef MAINUI_H
#define MAINUI_H

#include "Machine.h"
#include <fstream>
#include <string>
#define RED "\033[31m"
#define RESET "\033[0m"

class MainUI {
private:
    Machine machine;
   

public:
    void displayMenu();
    void inputFile();
    std::string inputInstruction();
};

#endif
