#ifndef REGISTER__H
#define REGISTER__H

#define RED "\033[31m"
#define RESET "\033[0m"
#include <iostream>

class Register {
    private:
    int memory[16] = {0};
    int size = 16;

    public:
    int getCell(const int& address) const;
    void setCell(int& address, int& val);

};

#endif