#include "MainUI.h"
#include "Machine.h"
#include <iostream>

int main() {
    MainUI ui;
    ui.displayMenu();
    return 0;
}
