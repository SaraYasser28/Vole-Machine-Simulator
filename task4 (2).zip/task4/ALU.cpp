#include <string>
#include <sstream>
#include <iomanip>
#include "ALU.h"
#include <iostream>
#include <bit>

int ALU::hexToDec(const std::string& hex) {
    int result;
    std::stringstream ss;
    ss << std::hex << hex;
    ss >> result;
    return result;
    return 0;
}

std::string ALU::decToHex(int& dec) {
   std::stringstream ss;
    ss << std::uppercase << std::setw(2) << std::setfill('0') << std::hex << dec;
    return ss.str();
   }



bool ALU::isValid(const std::string& value) {
    std::cout << "Validating input..." << std::endl;
    // Implement validation logic
    return true;
}

void ALU::add(int R, int S, int T, Register& reg) {
    std::cout << "Performing addition in ALU..." << std::endl;
    // Implement addition logic
}
void ALU::OR(int R, int S, int T, Register&reg){
    int val = reg.getCell(S) | reg.getCell(T);
    reg.setCell(R, val);
}
void ALU::AND(int R, int S, int T, Register&reg){
    int val = reg.getCell(S) & reg.getCell(T);
    reg.setCell(R, val);
}
void ALU::XOR(int R, int S, int T, Register&reg){
    int val = reg.getCell(S) ^ reg.getCell(T);
    reg.setCell(R, val);
}
