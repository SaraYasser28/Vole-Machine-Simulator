#include "MainUI.h"
#include <iostream>

void MainUI::displayMenu() {
    std::cout << "\nMenu:\nA) Load a Program from a File\nB) Enter Instructions Manually\nC) Exit";
    std::cout << "\nChoose an option: ";
    std::string choice;
    std::cin >> choice;

    if (choice == "A" || choice == "a") {
        inputFile();
    }else if (choice == "B" || choice == "b") {
        inputInstruction();
    }else if (choice == "C" || choice == "c") {
        std::cout << "\nExiting program...\n";
    } else {
        std::cerr << RED << "\n*Invalid choice*\n" << RESET;
        displayMenu();
    }
    
}

void MainUI::inputFile() {
    std::cout << "Enter the file name: ";
    std::string fileName;
    std::cin >> fileName;
    std::ifstream file(fileName);
    if (!file) {
        std::cerr << RED << "\nError: Unable to open file : " << fileName << RESET << std::endl;
        std::cerr << RED << "Please check the file path and extantion\n\n" << fileName << RESET;
        inputFile();
    }
    machine.loadProgramFile(file);
    machine.outputState();
}

std::string MainUI::inputInstruction() {
    std::string instruction;
    std::cout << "Enter the instruction (or 'C000' to HALT): ";
    std::cin >> instruction;
    return instruction;
}