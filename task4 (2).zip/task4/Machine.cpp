#include "Machine.h"
#include <iostream>
#include <fstream>

void Machine::loadProgramFile(std::ifstream& file) {
   std::string val;
   for(int i = 0; file >> val; i++) {
        processor.setMem().setCell(i++, val);
        if (file >> val) {
            processor.setMem().setCell(i, val);
        }else{
            std::cout << "\n**The memory must be even numbers check the input and try agein**\n";
            std::exit(EXIT_FAILURE);
        }
        processor.runNextStep();
    }
    file.close();
}

void Machine::outputState() {
    
    ALU a;
    std::cout << "\n MEMORY \n";
    for(int i = 0 ; i< 15 ; i++){
        //int cellValue = std::soi(memory.getCell(i));
        std::cout << a.decToHex(i)  <<" -> "<< processor.setMem().getCell(i) << std::endl;
    }
    std::cout << "\nREGISTER\n";
    for(int i = 0 ; i< 16 ; i++){
        int cellValue = processor.getReg().getCell(i);
        std::cout << a.decToHex(i)  <<" -> "<< a.decToHex(cellValue) << std::endl;
    }
}
