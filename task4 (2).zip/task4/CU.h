#ifndef CU_H
#define CU_H

#include "Register.h"
#include "Memory.h"

#define RED "\033[31m"
#define RESET "\033[0m"

class CU{
public:
    void load(int R, int XY, Register& reg, Memory& mem);
    void load(int R, int val, Register& reg);
    void store(int R, int XY, Register& reg, Memory& mem);
    void move(int R, int S, Register& reg);
    void jump(int R, int XY, Register& reg, int& PC, char& op);
    void rotate(int R, int X, Register& reg);

};

#endif