#include "CPU.h"
#include <iostream>
using namespace std;

Memory& CPU::setMem(){
    return memory;
}

Register& CPU::getReg() {
    return reg;
}

void CPU::fetch() {
   instruc = memory.getCell(pCounter) + memory.getCell(pCounter+1);
   pCounter += 2;
   std::cout << instruc <<std::endl;
}

void CPU::execute() {
    opCode = instruc[0];
    //op RXY
    int XY = alu.hexToDec(std::string(1, instruc[2]) + std::string(1, instruc[3]));
    int R = alu.hexToDec(std::string(1, instruc[1]));
    int S = alu.hexToDec(std::string(1, instruc[2]));
    int T = alu.hexToDec(std::string(1, instruc[3]));

    switch (opCode) {
        case '1':
            cu.load(R, XY, reg, memory);
            break;
        case '2':
            std::cout <<"b";
            cu.load(R, XY, reg);
            break;
        case '3':
            cu.store(R, XY, reg, memory);
            break;
        case '4':
            cu.move(R, S, reg);
            break;
        case '5':
            alu.add(R, S, T, reg);
            break;
        case '6':
            alu.add(R, S, T,reg);
            break;
        case '7':
            alu.OR(R, S, T, reg);
            break;
        case '8':
            alu.AND(R, S, T, reg);
            break;
        case '9':
            alu.XOR(R, S, T, reg);
            break;
        case 'A':
            cu.jump(R, XY, reg, pCounter, opCode);
            std::cout << pCounter;
            break;
        case 'B':
            cu.jump(R, XY, reg, pCounter, opCode);
            std::cout <<"jump to "<< pCounter <<std::endl;
            break;
        case 'C':
            std::cout << "\nProgram halted...\n";
            break;
        case 'D':
            cu.jump(R, XY, reg, pCounter, opCode);
            break;
        default:
            std::cerr << RED << "\n*Invalid opcode in memory[ " << pCounter-2 << " ]\n"<< RESET;
            std::exit(EXIT_FAILURE);
    }
    
}


void CPU::runNextStep() {
    fetch();
    execute();
}
