#ifndef CPU_H
#define CPU_H

#include <string>
#include <vector>
#include "Register.h"
#include "Memory.h"
#include "CU.h"
#include "ALU.h"

class CPU {
    protected:
    int pCounter;
    std::string instruc;
    char opCode;
    Register reg;
    Memory memory;
    ALU alu;
    CU cu;

    void fetch();
    void execute();

public:
    CPU() : pCounter(0){};
    Memory& setMem();
    void runNextStep();
    Register& getReg();
};

#endif