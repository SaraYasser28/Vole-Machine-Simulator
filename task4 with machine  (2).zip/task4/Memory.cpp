#include "Memory.h"

Memory::Memory() : memory(size, "00") {}

std::string Memory::getCell(int address) const {
    if (address >= 0 && address <= 256) {
        return memory[address];
    }

    std::cerr << RED << "\n**Invalid memory address**\n" << RESET;
    std::exit(EXIT_FAILURE);
}

void Memory::setCell(int address, const std::string& val) {
    if (address >= 0 && address <= 256) {
        memory[address] = val;
    }else {
        std::cerr << RED << "\n**Invalid memory address**\n" << RESET;
    }
}