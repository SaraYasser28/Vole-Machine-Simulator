#include <iostream>
#include <fstream>
#include "Machine.h"

Machine::Machine() = default;

Machine::Machine(int iMemory[], int iRegisters[], int iPc, int iIr, const string& iBuffer)
    : pc(iPc), ir(iIr), buffer(iBuffer) {
    for (int i = 0; i < 256; i++) {
        memory.setCell(i, iMemory[i]);
    }
    for (int i = 0; i < 16; i++) {
        reg[i] = iRegisters[i];
    }
}

void Machine::outputState() const {
    cout << "PC: " << pc << endl;
    cout << "IR: " << ir << endl;
    cout << "Registers: ";
    for (int i = 0; i < 16; i++) {
        cout << reg[i] << " ";
    }
    cout << endl;
}
