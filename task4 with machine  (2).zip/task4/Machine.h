#define MACHINE_H

#include <iostream>
#include <string>
#include "CPU.h"      // Assuming you have a CPU.h header file
#include "Memory.h"   // Assuming you have a Memory.h header file

using namespace std;

class Machine {
private:
    int reg[16] = {};
    int pc = 0;
    int ir = 0;
    string buffer;

public:
    Machine();
    Machine(int iMemory[], int iRegisters[], int iPc, int iIr, const string& iBuffer = "");

    void outputState() const;

    CPU processor;
    Memory memory;
};

#endif // MACHINE_H