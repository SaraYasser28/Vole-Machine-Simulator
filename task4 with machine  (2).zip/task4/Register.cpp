#include "Register.h"


int Register::getCell(const int& address) const {
    if (address >= 0 && address < 16) {
        return memory[address];
    }
    std::cerr << RED << "\n**Invalid register address**\n" << RESET;
    return -1;
}

void Register::setCell(int& address, int& val) {
    if (address >= 0 && address < 16) {
        memory[address] = val;
    } else {
        std::cerr << RED << "\n**Invalid register address**\n" << RESET;
    }
}
